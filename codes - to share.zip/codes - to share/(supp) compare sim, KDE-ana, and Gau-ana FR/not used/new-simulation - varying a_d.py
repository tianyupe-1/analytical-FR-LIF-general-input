import math
import random
import statistics
import matplotlib.pyplot as plt
import numpy as np
import scipy.stats as stats

def whitenoise(t):
	u1 = random.uniform(0,1)
	u2 = random.uniform(0,1)
	z = math.sqrt((-2)*math.log(u1))*math.cos(2*math.pi*u2)
	return z

## para and sim set up ##
# 1. The two OU-processes have the same paras, except for the coupling is from the 2nd to the 1st process
# 2. Simulate w.r.t. different miu, fixing other paras
# 3. For each set of paras, repeat 10 simulations to compute the SD (error margin)

dt = 1/10 # distance between 2 sample points, in ms
N = 10000 # total num of sampling intervals (num of sampling points -1) 
time_vec = np.linspace(0,N*dt,num=N+1) # time vec in ms
num_rep = 10 # num of repetations for each parameter set (to compute the SD for error margin)

# membrane para
ref = 1 # refractory period = 1ms
tao_m = 20 #16
V_r = -70
V_reset = -90
theta = 30 # distance between firing threshold and V_r
R = 1 # membrane resistance

# OU process currents
tao_s = 5
miu = 20 # mean of OU
k = 100
c_OU = 1 # "c" in paper, coupling strength

# 10Hz (alpha) sinusoidal driving current
osci_fq = 10
miu_d = 10 # mean value of the osci
a_d_vec = np.linspace(0, 200, num=21) # amplitude of the oscillation (max - miu_d)

# recording vectors and matrices
mean_FR_vec = [0]*len(a_d_vec) # record mean firing rate in each round;
mean_FR_mx = np.zeros((num_rep,len(a_d_vec)))
# 10 rows, each row records one round of sim across all values of the specified variable 

for m in range(num_rep):
	for j in range(len(a_d_vec)):
		
		# currents
		I_1 = [0]*(N+1)
		I_1[0] = miu
		dI_1 = [0]*(N+1)
		
		I_2 = [0]*(N+1)
		I_2[0] = miu
		dI_2 = [0]*(N+1)
		
		I_3 = [0]*(N+1)
		I_3[0] = miu_d
		
		for i in range(0,N):			
			dI_2[i] = -(1/tao_s)*dt*(I_2[i]- miu) + (k/tao_s)*math.sqrt(dt)*whitenoise(dt*i) 
			I_2[i+1] = I_2[i] + dI_2[i]	
			dI_1[i] = -(1/tao_s)*dt*(I_1[i]- miu) + (k/tao_s)*math.sqrt(dt)*whitenoise(dt*i) + (c_OU/tao_s)*dt*I_2[i]
			I_1[i+1] = I_1[i] + dI_1[i]
			I_3[i+1] = miu_d + a_d_vec[j]*np.sin(2*math.pi*osci_fq*dt*(1e-3)*(i+1))
		
		I_1 = np.array(I_1)
		I_2 = np.array(I_2)
		I_3 = np.array(I_3)
		I_tot = I_1 + I_2 + I_3
		
		# membrane potential
		V = [0]*(N+1)
		V[0] = V_r
		
		#x = [0]*(N+1) # this vector records the firings: 1 for firing, 0 for no firing
		dV = [0]*(N+1)
		
		firing_index_vec = [] # this vector records firing indices
		
		
		# I = [miu]*(N+1) # constant current
		
		for i in range(0,N):
			dV[i] = -(1/tao_m)*dt*(V[i]-V_r) + (1/tao_m)*R*I_tot[i]*dt
			V[i+1] = V[i] + dV[i]
			if V[i+1] >= theta + V_r:
				#x[i] = 1
				V[i+1] = V_reset
				firing_index = [i]
				firing_index_vec = np.concatenate([firing_index_vec,firing_index])
				
			if i == N-1:
				#NOF = sum(x)
				NOF = len(firing_index_vec) # number of firing
				mean_ISI = ref + ((firing_index_vec[-1] - firing_index_vec[0]) * dt)/(NOF-1) # ms
				mean_FR = 1000/mean_ISI # firing rate in Hz
				mean_FR_vec[j] = mean_FR
				
				#mean_ISI_vec[j] = mean_ISI
				
				#print(NOF)
				#print("ISI (ms) = ",ISI)
				#print("firing rate (Hz) = ",FR)
				#print(firing_index_vec)
		
		## compute SD
		
		## SD of FR		
		##FR_vec_current_trial =  [0]*(len(firing_index_vec)-1)
		##for i in range(len(firing_index_vec)-1):
			##FR_vec_current_trial[i] = 1000/(ref + dt*(firing_index_vec[i+1] - firing_index_vec[i]))	
		##SD_FR = statistics.stdev(FR_vec_current_trial)
		##SD_FR_vec[j] = SD_FR	
		
		## SD of ISI
		#ISI_vec_current_trial =  [0]*(len(firing_index_vec)-1)
		#for i in range(len(firing_index_vec)-1):
			#ISI_vec_current_trial[i] = dt*(firing_index_vec[i+1] - firing_index_vec[i])	
		
		#SD_ISI = statistics.stdev(ISI_vec_current_trial)
		#SD_ISI_vec[j] = SD_ISI			
		
	mean_FR_mx[m,:] = mean_FR_vec

total_mean_FR_vec = [0]*len(a_d_vec) # each value is the average of the "num_rep" of simulations of "mean_FR"
sd_vec = [0]*len(a_d_vec)
for i in range(len(a_d_vec)):
	total_mean_FR_vec[i] = np.mean(mean_FR_mx[:,i])
	sd_vec[i] = np.std(mean_FR_mx[:,i])

print("total average each =",total_mean_FR_vec)
print("sd each =",sd_vec)

plt.errorbar(a_d_vec, total_mean_FR_vec, yerr=sd_vec)
plt.xlabel('a_d')
plt.ylabel('mean firing rate (Hz)')
plt.title('compare analytical and simulated firing rate')
plt.legend()
#plt.grid(True)
plt.show()


#print("1st row=",mean_FR_mx[0,:])
#print("2nd row=",mean_FR_mx[1,:])
		
		
    
	    


#rows, cols = num_rep,len(a_d_vec)
#mean_FR_mx = [([0]*cols) for i in range(rows)] 












#mean_FR_vec = [0]*len(a_d_vec) # record mean firing rate in each trial; the trials are defined in the argument
##SD_FR_vec = [0]*len(a_d_vec) # record firing rate SD in each trial, the trials are defined in the argument

#mean_ISI_vec = [0]*len(a_d_vec) # record mean ISI in each trial; the trials are defined in the argument
#SD_ISI_vec = [0]*len(a_d_vec) # record ISI SD in each trial, the trials are defined in the argument

#tao_m = 16
#theta = 30
#R = 1
##num_current_fn = 3

#V_r = -70
#V_reset = -90



### Set of parameters
## 1. The first current fn

#tao_s_1 = 5
#sigma_1 = 100
##miu_1 = 30 # mean current


#current_sd_1 = math.sqrt(sigma_1**2/(2*tao_s_1))
#print ("current_sd_1 = ", current_sd_1)

## 2. The second current fn

#tao_s_2 = 100
#sigma_2 = 100*math.sqrt(2)
#miu_2 = -10 # 10 mean current

#current_sd_2 = math.sqrt(sigma_2**2/(2*tao_s_2))
#print ("current_sd_2 = ", current_sd_2)

## 3. The third current fn

#tao_s_3 = 100
#sigma_3 = 100*math.sqrt(2)
#miu_3 = 40 # 20 mean current

#current_sd_3 = math.sqrt(sigma_3**2/(2*tao_s_3))
#print ("current_sd_3 = ", current_sd_3)


## loop on a_d_vec

#for j in range(len(a_d_vec)):
	
	### Numerical current simulations:
	
	## 1. The first current fn	
	
	#I_1 = [0]*(N+1)
	#I_1[0] = a_d_vec[j]
	
	#x_1 = [0]*(N+1)
	#dI_1 = [0]*(N+1)
	
	#for i in range(0,N):
		#dI_1[i] = -(1/tao_s_1)*dt*(I_1[i]-a_d_vec[j]) + (sigma_1/tao_s_1)*math.sqrt(dt)*whitenoise(dt*i)
		#I_1[i+1] = I_1[i] + dI_1[i]
	
	
	## 2. The second current fn
	
	#I_2 = [0]*(N+1)
	#I_2[0] = miu_2
	
	#x_2 = [0]*(N+1)
	#dI_2 = [0]*(N+1)
	
	#for i in range(0,N):
		#dI_2[i] = -(1/tao_s_2)*dt*(I_2[i]-miu_2) + (sigma_2/tao_s_2)*math.sqrt(dt)*whitenoise(dt*i)
		#I_2[i+1] = I_2[i] + dI_2[i]
	
	## 2. The third current fn
	
	#I_3 = [0]*(N+1)
	#I_3[0] = miu_3
	
	#x_3 = [0]*(N+1)
	#dI_3 = [0]*(N+1)
	
	#for i in range(0,N):
		#dI_3[i] = -(1/tao_s_3)*dt*(I_3[i]-miu_3) + (sigma_3/tao_s_3)*math.sqrt(dt)*whitenoise(dt*i)
		#I_3[i+1] = I_3[i] + dI_3[i]
	
	## total current
	#I = [0]*(N+1)
	#for i in range(N+1):
		#I[i] = I_1[i] + I_2[i] + I_3[i]
	
			
	#V = [0]*(N+1)
	#V[0] = V_r
	
	##x = [0]*(N+1) # this vector records the firings: 1 for firing, 0 for no firing
	#dV = [0]*(N+1)
	
	#firing_index_vec = [] # this vector records firing indices
	
	
	## I = [miu]*(N+1) # constant current
	
	#for i in range(0,N):
		#dV[i] = -(1/tao_m)*dt*(V[i]-V_r) + (1/tao_m)*R*I[i]*dt
		#V[i+1] = V[i] + dV[i]
		#if V[i+1] >= theta + V_r:
			##x[i] = 1
			#V[i+1] = V_reset
			#firing_index = [i]
			#firing_index_vec = np.concatenate([firing_index_vec,firing_index])
			
		#if i == N-1:
			##NOF = sum(x)
			#NOF = len(firing_index_vec) # number of firing
			#mean_ISI = ref + ((firing_index_vec[-1] - firing_index_vec[0]) * dt)/(NOF-1) # ms
			#mean_FR = 1000/mean_ISI # firing rate in Hz
			#mean_FR_vec[j] = mean_FR
			#mean_ISI_vec[j] = mean_ISI
			##print(NOF)
			##print("ISI (ms) = ",ISI)
			##print("firing rate (Hz) = ",FR)
			##print(firing_index_vec)
	
	### compute SD
	
	## SD of FR		
	##FR_vec_current_trial =  [0]*(len(firing_index_vec)-1)
	##for i in range(len(firing_index_vec)-1):
		##FR_vec_current_trial[i] = 1000/(ref + dt*(firing_index_vec[i+1] - firing_index_vec[i]))	
	##SD_FR = statistics.stdev(FR_vec_current_trial)
	##SD_FR_vec[j] = SD_FR	
	
	## SD of ISI
	#ISI_vec_current_trial =  [0]*(len(firing_index_vec)-1)
	#for i in range(len(firing_index_vec)-1):
		#ISI_vec_current_trial[i] = dt*(firing_index_vec[i+1] - firing_index_vec[i])	
	
	#SD_ISI = statistics.stdev(ISI_vec_current_trial)
	#SD_ISI_vec[j] = SD_ISI		

#print ("mean Firing rate vec (Hz) = ", mean_FR_vec)
##print("firing rate SD vec (Hz) = ",SD_FR_vec)

#print ("mean ISI vec (Hz) = ", mean_ISI_vec)
#print("ISI SD vec (Hz) = ",SD_ISI_vec)