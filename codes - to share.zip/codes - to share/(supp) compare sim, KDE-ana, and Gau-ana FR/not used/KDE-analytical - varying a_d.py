import math
import random
import statistics
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import gaussian_kde
from scipy.integrate import quad

# analytical FR in response to constant current I
def current_to_FR(I):
    FR_I = 1/(tao_m*math.log((R*I + V_r - V_reset)/(R*I - theta))+ref)
    FR_I = 1000*FR_I # change unit from ms to s
    return FR_I

def whitenoise(t):
	u1 = random.uniform(0,1)
	u2 = random.uniform(0,1)
	z = math.sqrt((-2)*math.log(u1))*math.cos(2*math.pi*u2)
	return z

## para and set up ##
# 1. The two OU-processes have the same paras, except for the coupling is from the 2nd to the 1st process
# 2. Obtain analytical results w.r.t. different miu, fixing other paras


#dt = 1/10 # distance between 2 sample points, in ms
dt = 5
N = 100000 # total num of sampling intervals (num of sampling points -1) 
time_vec = np.linspace(0,N*dt,num=N+1) # time vec in ms

# membrane para
ref = 1 # refractory period = 1ms
tao_m = 20 #16
V_r = -70
V_reset = -90
theta = 30 # distance between firing threshold and V_r
R = 1 # membrane resistance

# OU process currents
tao_s = 5
miu = 20 # mean of OU
k = 100
#k=0
c_OU = 1 # "c" in paper, coupling strength

# 10Hz (alpha) sinusoidal driving current
osci_fq = 10
miu_d = 10 # mean value of the osci
a_d_vec = np.linspace(0, 200, num=21) # amplitude of the oscillation (max - miu_d)

# vector recording analytical FR
mean_FR_vec = [0]*len(a_d_vec) # record mean firing rate in each round;



# simulate input currents
for j in range(len(a_d_vec)):
	
	# currents
	I_1 = [0]*(N+1)
	I_1[0] = miu
	dI_1 = [0]*(N+1)
	
	I_2 = [0]*(N+1)
	I_2[0] = miu
	dI_2 = [0]*(N+1)
	
	I_3 = [0]*(N+1)
	I_3[0] = miu_d
	
	for i in range(0,N):			
		dI_2[i] = -(1/tao_s)*dt*(I_2[i]- miu) + (k/tao_s)*math.sqrt(dt)*whitenoise(dt*i) 
		I_2[i+1] = I_2[i] + dI_2[i]	
		dI_1[i] = -(1/tao_s)*dt*(I_1[i]- miu) + (k/tao_s)*math.sqrt(dt)*whitenoise(dt*i) + (c_OU/tao_s)*dt*I_2[i]
		I_1[i+1] = I_1[i] + dI_1[i]
		I_3[i+1] = miu_d + a_d_vec[j]*np.sin(2*math.pi*osci_fq*dt*(1e-3)*(i+1))
	
	I_1 = np.array(I_1)
	I_2 = np.array(I_2)
	I_3 = np.array(I_3)
	I_tot = I_1 + I_2 + I_3
	
	# kde and analytical FR
	kde = gaussian_kde(I_tot)
	integrand = lambda x: current_to_FR(x) * kde.evaluate(x)
	#expected_value, error = quad(integrand, theta/R, np.mean(I_tot) + 10*np.std(I_tot))
	expected_value, error = quad(integrand, theta/R, np.inf)
	mean_FR_vec[j] = expected_value
	
print("analytical FR=", mean_FR_vec)
        
