% heat maps, including the heatmap of fitting error

% err_mx_miu_omega = abs(mean_FR_mx_miu_omega_ana - mean_FR_mx_miu_omega_sim)./mean_FR_mx_miu_omega_sim;
% 
% err_mx_ad_miud = abs(mean_FR_mx_ad_miud_ana - mean_FR_mx_ad_miud_sim)./mean_FR_mx_ad_miud_sim;

% diff_mx_miu_omega = abs(mean_FR_mx_miu_omega_ana - mean_FR_mx_miu_omega_sim);
% 
% diff_mx_ad_miud = abs(mean_FR_mx_ad_miud_ana - mean_FR_mx_ad_miud_sim);

%data_mx = mean_FR_mx_ad_miud_ana;
data_mx = diff_mx_ad_miud;
x_tick_vec = miu_d_vec;
y_tick_vec = a_d_vec;

figure('Position',[100 30 600 500]); 
imagesc(data_mx);

% Make y-axis increase upward
set(gca, 'YDir', 'normal');

% Choose subset of ticks (every 2nd element)
xticks(1:2:length(x_tick_vec));
yticks(1:2:length(y_tick_vec));

% Assign tick labels for those positions
xticklabels(x_tick_vec(1:2:end));
yticklabels(y_tick_vec(1:2:end));

xlabel('miu_d');
ylabel('a_d');
title('diff - miu_d (mean drive) and a_d (osci amp of drive)');
colorbar;
colormap('cool');
clim([0 8]);           % values outside are clipped



% h = heatmap(data_mx);
% h.YDisplayData = flipud(h.YDisplayData);
% 
% 
% % Add labels
% xlabel('miu');
% ylabel('omega');
% xticks(miu_vec)
% yticks(osci_fq_vec)
% title('Heat map from matrix');