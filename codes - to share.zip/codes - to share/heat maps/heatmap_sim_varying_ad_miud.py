import math
import random
import seaborn as sns
import statistics
import matplotlib.pyplot as plt
import numpy as np
import scipy.stats as stats
from scipy.io import savemat

def whitenoise(t):
	u1 = random.uniform(0,1)
	u2 = random.uniform(0,1)
	z = math.sqrt((-2)*math.log(u1))*math.cos(2*math.pi*u2)
	return z

## para and sim set up ##
# 1. The two OU-processes have the same paras, except for the coupling is from the 2nd to the 1st process
# 2. Simulate w.r.t. different miu, fixing other paras
# 3. For each set of paras, repeat 10 simulations to compute the SD (error margin)

dt = 1/10 # distance between 2 sample points, in ms
N = 100000 # total num of sampling intervals (num of sampling points -1) 
time_vec = np.linspace(0,N*dt,num=N+1) # time vec in ms
# num_rep = 10 # num of repetations for each parameter set (to compute the SD for error margin)

# membrane para
ref = 1 # refractory period = 1ms
tao_m = 20 #16
V_r = -70
V_reset = -90
theta = 30 # distance between firing threshold and V_r
R = 1 # membrane resistance

# OU process currents
tao_s = 5
miu = 20 # varying mean
k = 100
c_OU = 1 # "c" in paper, coupling strength

# 10Hz (alpha) sinusoidal driving current
osci_fq = 10
miu_d_vec = np.linspace(0, 20, num=21)
# miu_d = 10 # mean value of the osci
a_d_vec = np.linspace(0, 200, num=21)
# a_d = 100 # amplitude of the oscillation (max - miu_d)

# recording vectors and matrices
mean_FR_vec = [0]*len(miu_d_vec) # record mean firing rate in each round of miu_d;
mean_FR_mx = np.zeros((len(a_d_vec),len(miu_d_vec)))
# record mean firing rate for each combination of parameters;

for m in range(len(a_d_vec)):
	for j in range(len(miu_d_vec)):
		
		# currents
		I_1 = [0]*(N+1)
		I_1[0] = miu
		dI_1 = [0]*(N+1)
		
		I_2 = [0]*(N+1)
		I_2[0] = miu
		dI_2 = [0]*(N+1)
		
		I_3 = [0]*(N+1)
		I_3[0] = miu_d_vec[j]
		
		for i in range(0,N):			
			dI_2[i] = -(1/tao_s)*dt*(I_2[i]- miu) + (k/tao_s)*math.sqrt(dt)*whitenoise(dt*i) 
			I_2[i+1] = I_2[i] + dI_2[i]	
			dI_1[i] = -(1/tao_s)*dt*(I_1[i]- miu) + (k/tao_s)*math.sqrt(dt)*whitenoise(dt*i) + (c_OU/tao_s)*dt*I_2[i]
			I_1[i+1] = I_1[i] + dI_1[i]
			I_3[i+1] = miu_d_vec[j] + a_d_vec[m]*np.sin(2*math.pi*osci_fq*dt*(1e-3)*(i+1))
		
		I_1 = np.array(I_1)
		I_2 = np.array(I_2)
		I_3 = np.array(I_3)
		I_tot = I_1 + I_2 + I_3
		
		# membrane potential
		V = [0]*(N+1)
		V[0] = V_r
		
		#x = [0]*(N+1) # this vector records the firings: 1 for firing, 0 for no firing
		dV = [0]*(N+1)
		
		firing_index_vec = [] # this vector records firing indices
		
		
		# I = [miu]*(N+1) # constant current
		
		for i in range(0,N):
			dV[i] = -(1/tao_m)*dt*(V[i]-V_r) + (1/tao_m)*R*I_tot[i]*dt
			V[i+1] = V[i] + dV[i]
			if V[i+1] >= theta + V_r:
				#x[i] = 1
				V[i+1] = V_reset
				firing_index = [i]
				firing_index_vec = np.concatenate([firing_index_vec,firing_index])
				
			if i == N-1:
				#NOF = sum(x)
				NOF = len(firing_index_vec) # number of firing
				mean_ISI = ref + ((firing_index_vec[-1] - firing_index_vec[0]) * dt)/(NOF-1) # ms
				mean_FR = 1000/mean_ISI # firing rate in Hz
				mean_FR_vec[j] = mean_FR
				
				#mean_ISI_vec[j] = mean_ISI
				
				#print(NOF)
				#print("ISI (ms) = ",ISI)
				#print("firing rate (Hz) = ",FR)
				#print(firing_index_vec)		
		
	mean_FR_mx[m,:] = mean_FR_vec

savemat("mean_FR_mx_ad_miud_sim.mat", {'mean_FR_mx_ad_miud_sim':mean_FR_mx})

ax = sns.heatmap(mean_FR_mx, annot=False, cmap='viridis')

# Invert y so omega increases upward
ax.invert_yaxis()

# Replace tick **labels** with your vectors
ax.set_xticklabels(miu_d_vec)
ax.set_yticklabels(a_d_vec)

# Force integer display (no decimals)
ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"{int(x)}"))
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: f"{int(y)}"))

plt.xlabel('miu_d')
plt.ylabel('a_d')
plt.title('heat map of simulated FR - miu_d (mean drive) and a_d (osci amp of drive)')
plt.show()

