
% Option A: same x for both vectors
x = a_d_vec;      % n-by-1
y1 = R_squared_IG_sim;     % n-by-1
y2 = R_squared_IG_ana;     % n-by-1

% Option B: different x for each vector
% x1 = ...; y1 = ...;
% x2 = ...; y2 = ...;

%% ---- Make sure vectors are columns ----
if exist('x','var')
    x  = x(:);  y1 = y1(:);  y2 = y2(:);
    x1 = x;     x2 = x;
else
    x1 = x1(:); y1 = y1(:);
    x2 = x2(:); y2 = y2(:);
end

%% ---- Fit separate lines (for plotting + reporting) ----
p1 = polyfit(x1, y1, 1);   % y1 ≈ p1(1)*x1 + p1(2)
p2 = polyfit(x2, y2, 1);   % y2 ≈ p2(1)*x2 + p2(2)

%% ---- Plot data (solid) + fitted lines (dashed) ----
figure; hold on; box on;

% Sort data by x so lines don't zig-zag
[x1s, idx1] = sort(x1);
y1s = y1(idx1);

[x2s, idx2] = sort(x2);
y2s = y2(idx2);

% Plot raw data as solid lines with markers
% plot(x1s, y1s, '-o', 'LineWidth', 2, 'MarkerSize', 6);
% plot(x2s, y2s, '-o', 'LineWidth', 2, 'MarkerSize', 6);

plot(x1s, y1s, 'b','LineWidth', 2);
plot(x2s, y2s, 'r','LineWidth', 2);
xlim([min(x),max(x)])
%xticks([0.8,1,2,3,4,5,6,7,8])
set(gca,'FontSize',20)
ylim([0,1])


% Regression lines (dashed)
xmin = min([x1; x2]);
xmax = max([x1; x2]);
xgrid = linspace(xmin, xmax, 200)';

y1hat = polyval(p1, xgrid);
y2hat = polyval(p2, xgrid);

plot(xgrid, y1hat,'--b', 'LineWidth', 2);
plot(xgrid, y2hat,'--r','LineWidth', 2);
xlim([min(x),max(x)])
%xticks([0.8,1,2,3,4,5,6,7,8])
set(gca,'FontSize',20)
ylim([0,1])

xlabel('a_d');
ylabel('R^2');
legend({'IG pdf (simulation)','IG pdf (analytical)', ...
        'IG pdf (simulation) - regression','IG pdf (analytical) - regression'}, ...
        'Location','best');

title('Data (solid) and linear regression (dashed)');



X = [x1; x2];
Y = [y1; y2];
G = [zeros(size(x1)); ones(size(x2))];

tbl = table(Y, X, G, 'VariableNames', {'Y','X','G'});
mdl = fitlm(tbl, 'Y ~ X*G');     % includes X, G, and X:G

% %% ---- Test if slopes are different (interaction test) ----
% % Model: y = b0 + b1*x + b2*G + b3*(x*G) + error
% % where G=0 for group1, G=1 for group2.
% % The slope difference is b3. Test H0: b3 = 0.
% 
% 
b3 = mdl.Coefficients.Estimate(strcmp(mdl.CoefficientNames,'X:G'));
p  = mdl.Coefficients.pValue(strcmp(mdl.CoefficientNames,'X:G'));

slope1 = mdl.Coefficients.Estimate(strcmp(mdl.CoefficientNames,'X'));
slope2 = slope1 + b3;

fprintf('IG pdf (simulation) slope: %.6g\n', slope1);
fprintf('IG pdf (analytical) slope: %.6g\n', slope2);
fprintf('Slope difference (Group2-Group1): %.6g\n', b3);
fprintf('p-value for slope difference (interaction X:G): %.6g\n', p);

% Optional: show the regression table in command window
disp(mdl);


%% ---- test if slope1 > slope2 ----
% termName = 'X:G';
% row = strcmp(mdl.CoefficientNames, termName);
% 
% b3    = mdl.Coefficients.Estimate(row);      % slope2 - slope1 (in the sense slope2 = slope1 + b3)
% se_b3 = mdl.Coefficients.SE(row);
% tval  = mdl.Coefficients.tStat(row);
% df    = mdl.DFE;                              % degrees of freedom for t-test
% 
% % slopes
% slope1 = mdl.Coefficients.Estimate(strcmp(mdl.CoefficientNames,'X'));
% slope2 = slope1 + b3;
% 
% % Two-sided p from fitlm (for reference)
% p_two = mdl.Coefficients.pValue(row);
% 
% % One-sided p for H1: slope1 > slope2  <=>  b3 < 0
% p_one = tcdf(tval, df);    % since p = P(T <= t_obs) under H0 for left-tail
% 
% fprintf('IG pdf (simulation) slope = %.6g\n', slope1);
% fprintf('IG pdf (analytical) slope = %.6g\n', slope2);
% fprintf('b3 = slope2 - slope1 = %.6g\n', b3);
% fprintf('t(%d) = %.6g\n', df, tval);
% fprintf('Two-sided p for b3=0: %.6g\n', p_two);
% fprintf('One-sided p for slope1 > slope2 (b3<0): %.6g\n', p_one);


%% ---- Fit ANCOVA model (same as before) ----
X = [x1; x2];
Y = [y1; y2];
G = [zeros(size(x1)); ones(size(x2))];   % 0=data1, 1=data2

tbl = table(Y, X, G, 'VariableNames', {'Y','X','G'});
mdl = fitlm(tbl, 'Y ~ X*G');             % includes X, G, and X:G



