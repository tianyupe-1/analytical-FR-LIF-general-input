x_axis = tao_m_over_tao_s;
%x_axis = a_d_vec;


plot(x_axis,R_squared_IG_sim,'k',x_axis,R_squared_IG_ana,'r','LineWidth',2)
hold on;
xlim([min(x_axis),max(x_axis)])
title('R-squared of IG densities compared with histogram from simulated data')
xlabel('tao_m_over_tao_s')
%xlabel('a_d')
legend({'R-squared - IG from simulation','R-squared - IG from analytical'},'FontSize', 18)