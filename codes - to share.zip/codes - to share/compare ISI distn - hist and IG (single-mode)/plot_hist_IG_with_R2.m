
% set up bins
dt = 0.1; % ms
ref = 1; % refractory period
bin_width = 1;
spk_idx = find(spk_binary_train==1);
ISI_vec = dt*diff(spk_idx)+ref;

max_val = ceil(max(ISI_vec));
eval_vec_hist = 0:bin_width:max_val; % edges in histgram
eval_vec_dist = 0.5*bin_width:bin_width:max_val-0.5*bin_width; % the evaluation of density fns are in the middle of bins
%eval_vec_dist = 0:bin_width:max_val-bin_width;

% IG density with analytical mu and lamda
IG_ana = makedist('InverseGaussian','mu',IG_mu_ana,'lambda',IG_lamda_ana);%establish whatever you want for mu and lambda
IG_pdf_ana = pdf(IG_ana,eval_vec_dist);
%plot(eval_vec,IG_pdf_ana);

% IG density with simulated mu and lamda
IG_sim = makedist('InverseGaussian','mu',IG_mu_sim,'lambda',IG_lamda_sim);%establish whatever you want for mu and lambda
IG_pdf_sim = pdf(IG_sim,eval_vec_dist);
%plot(eval_vec,IG_pdf_sim);

% histogram of simulated ISI
hist_sim = histogram(ISI_vec,eval_vec_hist,Normalization = 'pdf',DisplayStyle='stairs',FaceColor = 'none',LineWidth=1,EdgeColor='k');
hist_sim_values = hist_sim.Values;

sum_counts = sum(hist_sim_values);
width = hist_sim.BinWidth;
%%area of the histogram
area = sum_counts*width;

%hist_sim = histogram(ISI_vec,eval_vec_hist,Normalization = 'pdf',FaceColor = 'none',LineWidth=1,EdgeColor='k');
hold on
plot(eval_vec_dist,IG_pdf_ana,'r');
hold on
plot(eval_vec_dist,IG_pdf_sim,'b');
ylabel('probability')
xlabel('ISI(ms)')
xlim([0,140])
xticks(0:10:140)
legend('histogram of simulated data','IG pdf (analytical)','IG pdf (simulated)')



%% compute R^2
R_squared_IG_sim = R_square_compute(hist_sim_values, IG_pdf_sim);
R_squared_IG_ana = R_square_compute(hist_sim_values, IG_pdf_ana);


