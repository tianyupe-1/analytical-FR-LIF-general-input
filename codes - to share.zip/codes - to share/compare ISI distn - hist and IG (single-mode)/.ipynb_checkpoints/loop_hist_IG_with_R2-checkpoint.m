% In spk_binary_mx, each column represents a binary simulated spike train, 
% from which I obtain the ISI vector

% For each ISI vector, I compare its hist with IG (para from either this 
% ISI sim, or our analytical method)

dt = 0.1; %ms, sampling res

% computed IG paras
IG_mu_ana_vec = IG_mu_ana_vec;
IG_mu_sim_vec = IG_mu_sim_vec;
IG_lamda_ana_vec = IG_lamda_ana_vec;
IG_lamda_sim_vec = IG_lamda_sim_vec;

% simulated binary spk train
spk_binary_mx = spk_binary_mx;
%spk_binary_mx = spk_binary_mx(:,30);

% recording vec of R^2
R_squared_IG_sim = zeros(1,size(spk_binary_mx,2));
R_squared_IG_ana = zeros(1,size(spk_binary_mx,2));

for i = 1:size(spk_binary_mx,2)
    spk_binary = spk_binary_mx(:,i);
    spk_idx = find(spk_binary==1);
    ISI_vec = dt*diff(spk_idx);
    % set up bins
    bin_width = 1;
    max_val = max(ISI_vec);
    eval_vec_hist = 0:bin_width:ceil(max_val); % edges in histgram
    eval_vec_dist = 0.5*bin_width:bin_width:ceil(max_val)-0.5*bin_width; % the evaluation of density fns are in the middle of bins
    %eval_vec_dist = 0:bin_width:ceil(max_val)-bin_width; 

    % IG density with analytical mu and lamda
    IG_ana = makedist('InverseGaussian','mu',IG_mu_ana_vec(i),'lambda',IG_lamda_ana_vec(i));%establish whatever you want for mu and lambda
    IG_pdf_ana = pdf(IG_ana,eval_vec_dist);
    %plot(eval_vec,IG_pdf_ana);
    
    % IG density with simulated mu and lamda
    IG_sim = makedist('InverseGaussian','mu',IG_mu_sim_vec(i),'lambda',IG_lamda_sim_vec(i));%establish whatever you want for mu and lambda
    IG_pdf_sim = pdf(IG_sim,eval_vec_dist);
    %plot(eval_vec,IG_pdf_sim);
    
    % histogram of simulated ISI
    hist_sim = histogram(ISI_vec,eval_vec_hist,Normalization = 'pdf',DisplayStyle='stairs',FaceColor = 'none',LineWidth=1,EdgeColor='k');
    hist_sim_values = hist_sim.Values;
    
    % compute R^2
    R_squared_IG_sim(i) = R_square_compute(hist_sim_values, IG_pdf_sim);
    R_squared_IG_ana(i) = R_square_compute(hist_sim_values, IG_pdf_ana);

    hist_sim = histogram(ISI_vec,eval_vec_hist,Normalization = 'pdf',FaceColor = 'none',LineWidth=1,EdgeColor='k');
    hold on
    plot(eval_vec_dist,IG_pdf_ana,'r');
    hold on
    plot(eval_vec_dist,IG_pdf_sim,'b');
    ylabel('probability')
    xlabel('ISI(ms)')
    xlim([0,200])
    xticks(0:20:200)
    legend('histogram of simulated data','IG pdf (analytical)','IG pdf (simulated)')

end
%% plots

% % plot compare hist and IG
% hist_sim = histogram(ISI_vec,eval_vec_hist,Normalization = 'pdf',FaceColor = 'none',LineWidth=1,EdgeColor='k');
% hold on
% plot(eval_vec_dist,IG_pdf_ana,'r');
% hold on
% plot(eval_vec_dist,IG_pdf_sim,'b');
% ylabel('probability')
% xlabel('ISI(ms)')
% xlim([0,200])
% xticks(0:20:200)
% legend('histogram of simulated data','IG pdf (analytical)','IG pdf (simulated)')

% plot R^2







