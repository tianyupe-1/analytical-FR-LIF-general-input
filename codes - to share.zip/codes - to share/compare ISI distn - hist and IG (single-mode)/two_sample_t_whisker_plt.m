% Two vectors
x = R_squared_IG_ana(:);
y = R_squared_IG_sim(:);

% Remove NaNs
x = x(~isnan(x));
y = y(~isnan(y));

figure('Position',[200 200 520 420]); hold on;

% ----- Box-and-whisker plot (NO outliers) -----
boxplot([x; y], ...
        [ones(size(x)); 2*ones(size(y))], ...
        'Labels', {'analytical','simulated'}, ...
        'Symbol','');   % <-- removes red outlier markers

ylabel('R^2');
title('Box-and-whisker comparison');
grid on;

% Optional: overlay jittered individual data points
jit = 0.10;
% scatter(1 + (rand(size(x))-0.5)*2*jit, x, 18, 'filled', 'MarkerFaceAlpha', 0.5);
% scatter(2 + (rand(size(y))-0.5)*2*jit, y, 18, 'filled', 'MarkerFaceAlpha', 0.5);
xlim([0.5 2.5]);

% ----- Welch two-sample t-test -----
[h,p,ci,stats] = ttest2(x, y, 'Vartype','unequal');

fprintf('Welch t-test: p = %.4g, t(%g) = %.3f\n', p, stats.df, stats.tstat);
