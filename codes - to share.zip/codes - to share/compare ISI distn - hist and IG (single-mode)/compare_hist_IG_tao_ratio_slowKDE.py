# obtain the mx and vector including the info to compare ISI hist and IG (from KDE or sim),
# with data from varying a_d (drive amp)

import math
import random
import statistics
import matplotlib.pyplot as plt
import numpy as np
import scipy.stats as stats
from scipy.io import savemat
from scipy.stats import gaussian_kde
from scipy.integrate import quad

# analytical FR in response to constant current I
def current_to_FR(I,tao_m):
    FR_I = 1/(tao_m*math.log((R*I + V_r - V_reset)/(R*I - theta))+ref)
    FR_I = 1000*FR_I # change unit from ms to s
    return FR_I

def whitenoise(t):
	u1 = random.uniform(0,1)
	u2 = random.uniform(0,1)
	z = math.sqrt((-2)*math.log(u1))*math.cos(2*math.pi*u2)
	return z

## para and sim set up ##
# 1. The two OU-processes have the same paras, except for the coupling is from the 2nd to the 1st process
# 2. Simulate w.r.t. different miu, fixing other paras
# 3. For each set of paras, repeat 10 simulations to compute the SD (error margin)

# membrane para
ref = 1 # refractory period = 1ms
#tao_m_vec = np.linspace(1, 30, num=30) #20
tao_m_vec = np.linspace(4, 40, num=19)
V_r = -70
V_reset = -90
theta = 30 # distance between firing threshold and V_r
R = 1 # membrane resistance

# OU process currents
#tao_s = 2 # 5
tao_s = 5
miu = 20 # 20; mean of OU
k = 100
c_OU = 1 # "c" in paper, coupling strength

# 10Hz (alpha) sinusoidal driving current
osci_fq = 10
miu_d = 10 # 10, mean value of the osci
a_d = 50 #75 # amplitude of the oscillation (max - miu_d)

tao_m_over_tao_s = (1/tao_s)*tao_m_vec

# recording vectors and matrices
IG_mu_ana_vec = [0]*len(tao_m_vec) # 
IG_lamda_ana_vec = [0]*len(tao_m_vec) #
IG_mu_sim_vec = [0]*len(tao_m_vec) #
IG_lamda_sim_vec = [0]*len(tao_m_vec) #

dt = 1/10 # distance between 2 sample points in sim, in ms
N = 1000000 # total num of sampling intervals in sim (num of sampling points -1) 
time_vec = np.linspace(0,N*dt,num=N+1) # time vec in ms
spk_binary_mx = np.zeros((N,len(tao_m_vec))) # record the binary signal including spikes (denoted as 1)

dt_k = 5 # distance between 2 sample points, KDE-analytical, in ms
N_k = 20000 # total num of sampling intervals in KDE-analytical (num of sampling points -1) 
time_vec_k = np.linspace(0,N_k*dt_k,num=N_k+1) # time vec 


### currents and analytical FR (KDE)

for j in range(len(tao_m_vec)):    
    
	#dt_k = 5 # distance between 2 sample points, in ms
	#N_k = 20000 # total num of sampling intervals (num of sampling points -1) 
	#time_vec_k = np.linspace(0,N_k*dt_k,num=N_k+1) # time vec 
	
	I_1 = [0]*(N_k+1)
	I_1[0] = miu
	dI_1 = [0]*(N_k+1)
	
	I_2 = [0]*(N_k+1)
	I_2[0] = miu
	dI_2 = [0]*(N_k+1)
	
	I_3 = [0]*(N_k+1)
	I_3[0] = miu_d
	
	for i in range(0,N_k):			
		dI_2[i] = -(1/tao_s)*dt_k*(I_2[i]- miu) + (k/tao_s)*math.sqrt(dt_k)*whitenoise(dt_k*i) 
		I_2[i+1] = I_2[i] + dI_2[i]	
		dI_1[i] = -(1/tao_s)*dt_k*(I_1[i]- miu) + (k/tao_s)*math.sqrt(dt_k)*whitenoise(dt_k*i) + (c_OU/tao_s)*dt_k*I_2[i]
		I_1[i+1] = I_1[i] + dI_1[i]
		I_3[i+1] = miu_d + a_d*np.sin(2*math.pi*osci_fq*dt_k*(1e-3)*(i+1))
	
	I_1 = np.array(I_1)
	I_2 = np.array(I_2)
	I_3 = np.array(I_3)
	I_tot = I_1 + I_2 + I_3

	
	# kde and analytical results
	kde = gaussian_kde(I_tot)
	integrand_mean_FR = lambda x: current_to_FR(x,tao_m_vec[j]) * kde.evaluate(x)
	#expected_value, error = quad(integrand, theta/R, np.mean(I_tot) + 10*np.std(I_tot))
	mean_FR, error = quad(integrand_mean_FR, theta/R, np.inf)
	mean_ISI = 1000/mean_FR # simply related to FR
	
	integrand_var_ISI = lambda x: (((1/current_to_FR(x,tao_m_vec[j]))-mean_ISI)**2) * kde.evaluate(x)
	var_ISI, error = quad(integrand_var_ISI, theta/R, np.inf)
	SD_ISI = math.sqrt(var_ISI)
	
	# IG paras
	lamda = mean_ISI**3/var_ISI
	mu = var_ISI/mean_ISI**2 # the python built-in fn used a normalized IG density fn
	
	# IG paras for matlab use (not normalized)
	IG_mu_ana_vec[j] = mean_ISI
	IG_lamda_ana_vec[j] = lamda
	
	
	### simulation of membrane potential
	
	#dt = 1/10 # distance between 2 sample points, in ms
	#N = 1000000 # total num of sampling intervals (num of sampling points -1) 
	#time_vec = np.linspace(0,N*dt,num=N+1) # time vec in ms
	#num_rep = 10 # num of repetations for each parameter set (to compute the SD for error margin)

	I_1 = [0]*(N+1)
	I_1[0] = miu
	dI_1 = [0]*(N+1)
	
	I_2 = [0]*(N+1)
	I_2[0] = miu
	dI_2 = [0]*(N+1)
	
	I_3 = [0]*(N+1)
	I_3[0] = miu_d
	
	for i in range(0,N):			
		dI_2[i] = -(1/tao_s)*dt*(I_2[i]- miu) + (k/tao_s)*math.sqrt(dt)*whitenoise(dt*i) 
		I_2[i+1] = I_2[i] + dI_2[i]	
		dI_1[i] = -(1/tao_s)*dt*(I_1[i]- miu) + (k/tao_s)*math.sqrt(dt)*whitenoise(dt*i) + (c_OU/tao_s)*dt*I_2[i]
		I_1[i+1] = I_1[i] + dI_1[i]
		I_3[i+1] = miu_d + a_d*np.sin(2*math.pi*osci_fq*dt*(1e-3)*(i+1))
	
	I_1 = np.array(I_1)
	I_2 = np.array(I_2)
	I_3 = np.array(I_3)
	I_tot = I_1 + I_2 + I_3        	
	
	# membrane potential
	V = [0]*(N+1)
	V[0] = V_r
	
	#x = [0]*(N+1) # this vector records the firings: 1 for firing, 0 for no firing
	dV = [0]*(N+1)
	
	firing_index_vec = [] # this vector records firing indices
	
	
	# I = [miu]*(N+1) # constant current
	
	for i in range(0,N):
		dV[i] = -(1/tao_m_vec[j])*dt*(V[i]-V_r) + (1/tao_m_vec[j])*R*I_tot[i]*dt
		V[i+1] = V[i] + dV[i]
		if V[i+1] >= theta + V_r:
			#x[i] = 1
			V[i+1] = V_reset
			firing_index = [i]
			firing_index_vec = np.concatenate([firing_index_vec,firing_index])
			spk_binary_mx[i,j] = 1
			
		if i == N-1:
			#NOF = sum(x)
			NOF = len(firing_index_vec) # number of firing
			ISI_vec = ref + np.diff(firing_index_vec)*dt
			mean_ISI_sim = ref + ((firing_index_vec[-1] - firing_index_vec[0]) * dt)/(NOF-1) # ms
			mean_FR_sim = 1000/mean_ISI_sim # firing rate in Hz
			
			var_ISI_sim = np.var(ISI_vec)
			SD_ISI_sim = math.sqrt(var_ISI_sim)
			
			# IG paras
			lamda_sim = mean_ISI_sim**3/var_ISI_sim
			mu_sim = var_ISI_sim/mean_ISI_sim**2 # the python built-in fn used a normalized IG density fn
			
			# IG paras for matlab use (not normalized)
			IG_mu_sim_vec[j] = mean_ISI_sim
			IG_lamda_sim_vec[j] = lamda_sim
		    
			
		
#print ("Mean FR analytical (Hz) = ", mean_FR)
#print ("Mean ISI analytical (ms) = ", mean_ISI) 
#print ("SD ISI analytical (ms) = ", SD_ISI) 

#print ("Mean FR simulated (Hz) = ", mean_FR_sim)
#print ("Mean ISI simulated (ms) = ", mean_ISI_sim) 
#print ("SD ISI simulated (ms) = ", SD_ISI_sim) 


### comparison plot

##var_ISI = 40.7

#bins = np.linspace(0,100,101)

#lamda = mean_ISI**3/var_ISI
#mu = var_ISI/mean_ISI**2 # the python built-in fn used a normalized IG density fn

#lamda_sim = mean_ISI_sim**3/var_ISI_sim
#mu_sim = var_ISI_sim/mean_ISI_sim**2

#plt.hist(ISI_vec,bins,density = True, fill=False, histtype='step', color='k', label='histogram of simulated data')
##plt.plot(bins, hist(ISI_vec,bins,density = True), color='k', label='histogram of simulated data')
#plt.plot(bins, stats.invgauss.pdf(bins, mu, 0, lamda), color='r', label='IG pdf (analytical)') # IG pdf with analytical mean & var
#plt.plot(bins, stats.invgauss.pdf(bins, mu_sim, 0, lamda_sim), color='b', label='IG pdf (simulated)') # IG pdf with sim mean & var
#plt.legend()
#plt.title("Compare simulated and predicted ISI distributions")
#plt.xlabel("time (ms)")
#plt.ylabel("density")
#plt.show()


#savemat("ISI_vec.mat", {'ISI_vec':ISI_vec})
savemat("IG_mu_ana_vec.mat", {'IG_mu_ana_vec':IG_mu_ana_vec})
savemat("IG_lamda_ana_vec.mat", {'IG_lamda_ana_vec':IG_lamda_ana_vec})
savemat("IG_mu_sim_vec.mat", {'IG_mu_sim_vec':IG_mu_sim_vec})
savemat("IG_lamda_sim_vec.mat", {'IG_lamda_sim_vec':IG_lamda_sim_vec})
savemat("spk_binary_mx.mat", {'spk_binary_mx':spk_binary_mx})
savemat("tao_m_over_tao_s.mat",{'tao_m_over_tao_s':tao_m_over_tao_s})


print('IG_mu_ana_vec=',IG_mu_ana_vec)
print('IG_lamda_ana_vec=',IG_lamda_ana_vec)
print('IG_mu_sim_vec=',IG_mu_sim_vec)
print('IG_lamda_sim_vec=',IG_lamda_sim_vec)

