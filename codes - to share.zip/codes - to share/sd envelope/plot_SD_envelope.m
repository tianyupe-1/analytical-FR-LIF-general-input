% plot_SD_envelope


% 1. Plot the lower bound (=ref  - SD) & upper bound (=ref + SD)

% mean_FR_vec_ana = low_res_tao_m_ana;
% 
ana = mean_FR_vec_ana;
sim = total_mean_FR_vec_sim;
sem_sig = sd_vec;
x_axis = tao_m_over_tao_s_vec;


% ref_ori = load(strcat('FR_Vim_', string(fq),'Hz'));
% spk_ori = load(strcat('spk_Vim_', string(fq),'Hz'));
% SD_sig = load(strcat('SD_psth_Vim_', string(fq),'Hz'));
% 
% 
% ref_ori = ref_ori.(strcat('FR_Vim_', string(fq),'Hz'));
% spk_ori = spk_ori.(strcat('spk_Vim_', string(fq),'Hz'));
% SD_sig = SD_sig.(strcat('SD_psth_Vim_', string(fq),'Hz'));

% len = length(sem_sig);
% dt = 0.1;
% 
% time_vec = 0:dt:(len-1)*dt;


% ana = ana(1:len);
% sim = sim(1:len);

upper_bound = sim + sem_sig;
lower_bound = sim - sem_sig;

for i = 1:length(lower_bound)
    if lower_bound(i)<0
        lower_bound(i) = 0;
    end
end

% 

patch([x_axis fliplr(x_axis)], [lower_bound fliplr(upper_bound)],[0.25,0.878,0.816] ,'EdgeColor','none')
hold on;
plot(x_axis,sim,'k',x_axis,ana,'r','LineWidth',2)
hold on;
xlim([min(x_axis),max(x_axis)])
title('varying tao_m_over_tao_s')
legend({'sem envelope','simulation','KDE-analytical'},'FontSize', 18)

%% exp data
% % 1. Plot the lower bound (=ref PSTH - SD) & upper bound (=ref PSTH + SD)
% 
% 
% fit_ori = opt_fit_FR_100Hz_vim;
% ref_ori = FR_psth_100Hz_Vim;
% SD_sig = SD_psth_Vim_100Hz;
% 
% 
% % ref_ori = load(strcat('FR_Vim_', string(fq),'Hz'));
% % spk_ori = load(strcat('spk_Vim_', string(fq),'Hz'));
% % SD_sig = load(strcat('SD_psth_Vim_', string(fq),'Hz'));
% % 
% % 
% % ref_ori = ref_ori.(strcat('FR_Vim_', string(fq),'Hz'));
% % spk_ori = spk_ori.(strcat('spk_Vim_', string(fq),'Hz'));
% % SD_sig = SD_sig.(strcat('SD_psth_Vim_', string(fq),'Hz'));
% 
% %len = length(SD_sig);
% len = 20001;
% 
% dt = 0.1;
% time_vec = 0:dt:(len-1)*dt;
% 
% 
% fit = fit_ori(1:len);
% ref = ref_ori(1:len);
% SD_sel = SD_sig(1:len);
% 
% 
% upper_bound = ref + SD_sel;
% lower_bound = ref - SD_sel;
% 
% for i = 1:length(lower_bound)
%     if lower_bound(i)<0
%         lower_bound(i) = 0;
%     end
% end
% 
% % 
% 
% patch([time_vec fliplr(time_vec)], [lower_bound' fliplr(upper_bound')],[0.25,0.878,0.816] ,'EdgeColor','none')
% hold on;
% plot(time_vec,ref','k',time_vec,fit','r','LineWidth',2)
% hold on;
% set(gca,'FontSize',20)
% title('Compare PSTH FR, ODE simulated FR, 5Hz DBS, STN')
% legend({'SD envelope','PSTH FR','fit'},'FontSize', 18)
% 
