% for each spike train, select the segment during DBS 
% Then compute PSTH for each spike train

% ST = 3; %starting time of DBS

ST = 3;
TW = 50; %PSTH constant kernel width
dt = 0.1;
SPK_all_trial = SPK_all_trial; % spike trains from all trials
sel_len = size(SPK_all_trial,1)-30000; % the selected length of data used in computations


L = size(SPK_all_trial,2);
SPK_all_trial_plot = zeros(sel_len,L);
FR_psth_all_trial = zeros(sel_len,L);


for i = 1:L
    SPK_all_trial_plot(:,i) = SPK_all_trial(ST*1e4+1:ST*1e4+sel_len,i);
    FR_psth_all_trial(:,i) = PSTH_FR_def_left(SPK_all_trial_plot(:,i), dt,TW, 1);
end

% check plot
figure; hold on
ax(1) = subplot(5,1,1); plot(FR_psth_all_trial(:,1))
ax(2) = subplot(5,1,2); plot(FR_psth_all_trial(:,2))
ax(3) = subplot(5,1,3); plot(FR_psth_all_trial(:,3))
% ax(4) = subplot(5,1,4); plot(FR_psth_all_trial(:,4))
% ax(5) = subplot(5,1,5); plot(FR_psth_all_trial(:,5))

% a = FR_psth_all_trial(:,1);
% FR_psth_all_trial = zeros(sel_len,L);
% FR_psth_all_trial(:,1)=a; 

FR_psth_all_trial(:,20) = 0;

% SD envelope; compute the SD across all trials
SD_psth = zeros(sel_len,1);

for i = 1:sel_len
    
    SD_psth(i) = std(FR_psth_all_trial(i,:));
    
end

plot(SD_psth)

