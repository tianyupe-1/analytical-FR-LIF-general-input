import math
import random
import statistics
import matplotlib.pyplot as plt
import numpy as np
import scipy.stats as stats
from scipy.stats import gaussian_kde
from scipy.io import savemat

# analytical FR in response to constant current I
def current_to_FR(I):
    FR_I = 1/(tao_m*math.log((R*I + V_r - V_reset)/(R*I - theta))+ref)
    FR_I = 1000*FR_I # change unit from ms to s
    return FR_I

def whitenoise(t):
    u1 = random.uniform(0,1)
    u2 = random.uniform(0,1)
    z = math.sqrt((-2)*math.log(u1))*math.cos(2*math.pi*u2)
    return z

## para and set up ##
# 1. The two OU-processes have the same paras, except for the coupling is from the 2nd to the 1st process
# 2. Obtain analytical results w.r.t. different miu, fixing other paras


dt_vec = np.linspace(0.5,10,num=20) # ms, vec of KDE sampling interval
rho_vec = np.linspace(0.2,4,num=20) # ratio of the KDE-bandwidth to the default


#rho_vec = np.linspace(0.5,1,num=2) # ratio of the KDE-bandwidth to the default

total_sim_time = 100 # s

#r2_mx = np.zeros((len(dt_vec),len(rho_vec)))

#dt = 5 # ms, KDE sampling interval

for ii in range(len(dt_vec)):
    
    N = round(total_sim_time*1000/dt_vec[ii]) # total num of sim sampling intervals (num of sampling points -1) 
    
    #dt = 5
    #N = 100000 # total num of sim sampling intervals (num of sampling points -1) 
    
    time_vec = np.linspace(0,N*dt_vec[ii],num=N+1) # time vec in ms
    
    # membrane para
    ref = 1 # refractory period = 1ms
    tao_m = 20 #16
    V_r = -70
    V_reset = -90
    theta = 30 # distance between firing threshold and V_r
    R = 1 # membrane resistance
    
    # OU process currents
    tao_s = 5
    
    miu = 20 # varying mean
    k = 50
    c_OU = 1 # "c" in paper, coupling strength
    
    # 10Hz (alpha) sinusoidal driving current
    osci_fq = 10
    miu_d = 10 # mean value of the osci
    a_d = 125 # amplitude of the oscillation (max - miu_d)
    
    # vector recording analytical FR
    #mean_FR_vec = [0]*len(miu_vec) # record mean firing rate in each round;
    
    # simulate input currents
    
    # currents
    I_1 = [0]*(N+1)
    I_1[0] = miu
    dI_1 = [0]*(N+1)
    
    I_2 = [0]*(N+1)
    I_2[0] = miu
    dI_2 = [0]*(N+1)
    
    I_3 = [0]*(N+1)
    I_3[0] = miu_d
    
    for i in range(0,N):			
        dI_2[i] = -(1/tao_s)*dt_vec[ii]*(I_2[i]- miu) + (k/tao_s)*math.sqrt(dt_vec[ii])*whitenoise(dt_vec[ii]*i) 
        I_2[i+1] = I_2[i] + dI_2[i]	
        dI_1[i] = -(1/tao_s)*dt_vec[ii]*(I_1[i]- miu) + (k/tao_s)*math.sqrt(dt_vec[ii])*whitenoise(dt_vec[ii]*i) + (c_OU/tao_s)*dt_vec[ii]*I_2[i]
        I_1[i+1] = I_1[i] + dI_1[i]
        I_3[i+1] = miu_d + a_d*np.sin(2*math.pi*osci_fq*dt_vec[ii]*(1e-3)*(i+1))
    
    I_1 = np.array(I_1)
    I_2 = np.array(I_2)
    I_3 = np.array(I_3)
    I_tot = I_1 + I_2 + I_3
    
    bins = np.linspace(min(I_tot), max(I_tot), 101)
    
    # hist
    hist_pdf, bin_edges = np.histogram(I_tot, bins=bins, density=True)   
    
    #kde = gaussian_kde(I_tot)
    #kde_pdf = kde(bins[:-1])

    ## R^2 compute
    #ss_res = np.sum((hist_pdf - kde_pdf)**2)
    #ss_tot = np.sum((hist_pdf - np.mean(hist_pdf))**2)


    
    # kde pdf
    for jj in range(len(rho_vec)):
        kde = gaussian_kde(I_tot, bw_method=rho_vec[jj] * I_tot.size**(-0.2))
        #kde = gaussian_kde(I_tot, bw_method=1.0)
        #kde = gaussian_kde(I_tot)
        kde_pdf = kde(bins[:-1])
    
	# R^2 compute
        ss_res = np.sum((hist_pdf - kde_pdf)**2)
        ss_tot = np.sum((hist_pdf - np.mean(hist_pdf))**2)
    
        r2 = 1.0 - ss_res / ss_tot
        r2_mx[ii, jj] = r2


savemat("r2_mx.mat", {'r2_mx':r2_mx})
print("R2_mx = ",r2_mx)	
	
   
    

    
    
    ## compare I hist, Gaussian pdf, and KDE pdf
    ##plt.hist(I_tot,bins,density = True, fill=False, histtype='step', color='k', label='histogram of total input current')
    #plt.plot(bins[:-1], hist_pdf, color='k', label='histogram')
    ##plt.plot(bins[:-1], stats.norm.pdf(bins[:-1], np.mean(I_tot), np.std(I_tot)), color='b', label='normal density') 
    #plt.plot(bins[:-1], kde_pdf, color='r', label='KDE density') 
    #plt.legend()
    #plt.title("Compare histogram, normal and KDE distribution")
    #plt.ylabel("density")
    #plt.show()
	
	
	#integrand = lambda x: current_to_FR(x) * kde.evaluate(x)
	##expected_value, error = quad(integrand, theta/R, np.mean(I_tot) + 10*np.std(I_tot))
	#expected_value, error = quad(integrand, theta/R, np.inf)
	#mean_FR_vec[j] = expected_value
	
#print("analytical FR=", mean_FR_vec)
        
