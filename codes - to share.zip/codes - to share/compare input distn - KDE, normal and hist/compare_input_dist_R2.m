% compare input dist - hist, Gaussian and KDE

% prepared data
I_vec = I_vec; % the input current
kde_pdf = kde_pdf(1:end-1); 
% the kde estimate of the input distribution (from python); last value removed due to the
% consistent comparison with hist (see below for bin setup)

% set up bins
bins = linspace(min(I_vec), max(I_vec), 101);
eval_vec_hist = bins;
eval_vec_dist = bins(1:end-1); 
% in hist, the end value is the same as the 2nd last value because they are
% in the same bin

% bin_width = 1;
% max_val = 160;
% eval_vec_hist = 0:bin_width:max_val; % edges in histgram
% eval_vec_dist = 0.5*bin_width:bin_width:max_val-0.5*bin_width; % the evaluation of density fns are in the middle of bins

% normal density with simulated mu and sigma (sd) of input
normal_dist = makedist('Normal','mu',mu_I,'sigma',sigma_I);%establish whatever you want for mu and lambda
normal_dist_pdf = pdf(normal_dist,eval_vec_dist);
%plot(eval_vec,IG_pdf_ana);

% histogram of input
hist_I = histogram(I_vec,eval_vec_hist,Normalization = 'pdf',DisplayStyle='stairs',FaceColor = 'none',LineWidth=1,EdgeColor='k');
hist_I_values = hist_I.Values;

sum_counts = sum(hist_I_values);
width = hist_I.BinWidth;
%%area of the histogram
area = sum_counts*width;

%hist_sim = histogram(ISI_vec,eval_vec_hist,Normalization = 'probability',FaceColor = 'none',LineWidth=1,EdgeColor='k');
hold on
plot(eval_vec_dist,kde_pdf,'r');
hold on
plot(eval_vec_dist,normal_dist_pdf,'b');
ylabel('probability density')
xlabel('I')
% xlim([0,200])
% xticks(0:20:200)
legend('histogram of input current','kde pdf','normal pdf')


% hist_sim = histogram(ISI_vec,eval_vec_hist,Normalization = 'probability',DisplayStyle='stairs',FaceColor = 'none',LineWidth=1,EdgeColor='k');
% %hist_sim = histogram(ISI_vec,eval_vec_hist,Normalization = 'probability',FaceColor = 'none',LineWidth=1,EdgeColor='k');
% hold on
% plot(eval_vec_dist,IG_pdf_ana,'r');

%% compute R^2
R_squared_kde = R_square_compute(hist_I_values, kde_pdf);
R_squared_normal = R_square_compute(hist_I_values, normal_dist_pdf);



