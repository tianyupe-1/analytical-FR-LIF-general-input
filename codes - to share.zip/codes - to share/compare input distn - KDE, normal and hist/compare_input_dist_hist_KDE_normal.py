import math
import random
import statistics
import matplotlib.pyplot as plt
import numpy as np
import scipy.stats as stats
from scipy.stats import gaussian_kde
from scipy.io import savemat

ref = 1 # refractory period = 1ms

tao_m = 20 #16

# two OU processes
tao_s = 5
miu = 20 #30

# the third input current is sinusoid (y(t)=sin(2*pi*osci_fq*t)), which immitates external driving
# force with specific fq (e.g., alpha band)
miu_d = 10
osci_fq = 10 # 10:typical fq in alpha band; 20: a typical fq in beta band
a_d = 100

# tao_s = 5
theta = 30
R = 1
k = 100 #100
#c_OU = 1 # coupling strength
c_OU = 1

V_r = -70
V_reset = -90
# c = V_r - V_reset

#tao_s_vec = np.linspace(3, 30, num=28) # varying tao_s


# mean_FR_vec = [0]*len(tao_s_vec) # record mean firing rate in each trial; the trials are defined in the argument

def whitenoise(t):
	u1 = random.uniform(0,1)
	u2 = random.uniform(0,1)
	z = math.sqrt((-2)*math.log(u1))*math.cos(2*math.pi*u2)
	return z

dt = 5 # distance between 2 sample points, in ms
N = 20000 # N+1 = number of sample points, total = 100s (consistent with ht map)
time_vec = np.linspace(0,N*dt,num=N+1) # time vec in ms

# coupled OU processes

I_1 = [0]*(N+1)
I_1[0] = miu
dI_1 = [0]*(N+1)

I_2 = [0]*(N+1)
I_2[0] = miu
dI_2 = [0]*(N+1)

I_3 = [0]*(N+1)
I_3[0] = miu_d

for i in range(0,N):
	#dI_2[i] = -(1/tao_s)*dt*(I_2[i]- miu) + (k/tao_s)*math.sqrt(dt)*whitenoise(dt*i)
	dI_2[i] = -(1/tao_s)*dt*(I_2[i]- miu) + (k/tao_s)*math.sqrt(dt)*whitenoise(dt*i) 
	I_2[i+1] = I_2[i] + dI_2[i]	
	dI_1[i] = -(1/tao_s)*dt*(I_1[i]- miu) + (k/tao_s)*math.sqrt(dt)*whitenoise(dt*i) + (c_OU/tao_s)*dt*I_2[i]
	I_1[i+1] = I_1[i] + dI_1[i]
	I_3[i+1] = miu_d + a_d*np.sin(2*math.pi*osci_fq*dt*(1e-3)*(i+1))

I_1 = np.array(I_1)
I_2 = np.array(I_2)
I_3 = np.array(I_3)
I_tot = I_1 + I_2 + I_3

# I_tot = [x+y for x,y in zip(I_1,I_2)]

# dist of the total current
I = I_tot

# Create KDE object
kde = gaussian_kde(I)

# get the pdf of KDE
bins = np.linspace(min(I), max(I), 101)
kde_pdf = kde.evaluate(bins) 

# compare I hist, Gaussian pdf, and KDE pdf
plt.hist(I,bins,density = True, fill=False, histtype='step', color='k', label='histogram of total input current')
plt.plot(bins, stats.norm.pdf(bins, np.mean(I), np.std(I)), color='b', label='normal density') 
plt.plot(bins, kde_pdf, color='r', label='KDE density') 
plt.legend()
plt.title("Compare histogram, normal and KDE distribution")
plt.ylabel("density")
plt.show()

savemat("I_vec.mat", {'I_vec':I})
savemat("kde_pdf.mat", {'kde_pdf':kde_pdf})
savemat("mu_I.mat", {'mu_I':np.mean(I)})
savemat("sigma_I.mat", {'sigma_I':np.std(I)})


#print(len(kde_pdf))

#bins = np.linspace(min(I),max(I),101)
#plt.hist(I,bins,density = True, fill=False, histtype='step', color='k', label='histogram of total input current')
#plt.plot(bins, stats.norm.pdf(bins, np.mean(I), np.std(I)), color='b', label='normal distribution') 
#plt.legend()
#plt.title("Compare histogram and normal distribution")
#plt.ylabel("density")
#plt.show()


#plt.figure(figsize=(16,12))
#plt.subplot(411)
#plt.plot(time_vec, I_1, 'r', label='I_1')
#plt.xlabel("Time (ms)")
#plt.subplot(412)
#plt.plot(time_vec, I_2, 'b', label='I_2')
#plt.xlabel("Time (ms)")
#plt.subplot(413)
#plt.plot(time_vec, I_3, 'y', label='I_3')
#plt.xlabel("Time (ms)")
#plt.subplot(414)
#plt.plot(time_vec, I_tot, 'y', label='I_tot')
#plt.xlabel("Time (ms)")
#plt.show()
