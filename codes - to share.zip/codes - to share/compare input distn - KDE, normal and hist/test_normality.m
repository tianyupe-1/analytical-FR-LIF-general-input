% Example data

data = I_vec;  % Normally distributed sample

% % 1. Lilliefors test (Kolmogorov–Smirnov variant for normality)
% [h_lillie, p_lillie] = lillietest(data);
% if h_lillie == 0
%     fprintf('Lilliefors test: Data appears normal (p = %.4f)\n', p_lillie);
% else
%     fprintf('Lilliefors test: Data is not normal (p = %.4f)\n', p_lillie);
% end
% 
% % 2. Jarque-Bera test
% [h_jb, p_jb] = jbtest(data);
% if h_jb == 0
%     fprintf('Jarque-Bera test: Data appears normal (p = %.4f)\n', p_jb);
% else
%     fprintf('Jarque-Bera test: Data is not normal (p = %.4f)\n', p_jb);
% end

% 3. Kolmogorov–Smirnov test (requires mean & std)
mu = mean(data);
sigma = std(data);
[h_ks, p_ks] = kstest((data - mu) / sigma);
if h_ks == 0
    fprintf('KS test: Data appears normal (p = %.4f)\n', p_ks);
else
    fprintf('KS test: Data is not normal (p = %.4f)\n', p_ks);
end

% Shapiro-Wilk test


% Perform Shapiro–Wilk test
% [H, pValue, W] = swtest(data, 0.05);  % 0.05 is significance level
% 
% if H == 0
%     fprintf('Shapiro-Wilk: Data appears normal (W=%.4f, p=%.4f)\n', W, pValue);
% else
%     fprintf('Shapiro-Wilk: Data is NOT normal (W=%.4f, p=%.4f)\n', W, pValue);
% end
