function R_squared = R_square_compute(signal, pred)

err_vec = signal - pred;
mean_sig = mean(signal);
SS_err = sum(err_vec.^2);
shift_sig = signal - mean_sig;
SS_tot = sum(shift_sig.^2);

R_squared = 1 - SS_err/SS_tot;
